package com.kreitek.state;

public class OperationNotAllowedException extends Throwable {
}
