package com.kreitek.editor.commands;

import java.util.ArrayList;
import java.util.List;
import com.kreitek.editor.commands.Memento;

public class Caretaker {

    private static List<Memento> mementos = new ArrayList<>();
    private Memento WASD = new Memento();

    public void push(Memento state) {
        mementos.add(state);
    }


    public static Memento pop(){
        if (mementos.size() > 0){
            Memento memento = mementos.get(mementos.size() - 1);
            mementos.remove(mementos.size() -1);
            return  memento;
        }
        return null;
    }
}
