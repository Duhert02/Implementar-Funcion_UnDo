package com.kreitek.editor.commands;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Memento {
    public static Collection<String> getState;
    private List<String> documentLines = new ArrayList<String>();

    public Memento(){
        this.documentLines.addAll(documentLines);
    }

    public List<String> getState(){
     return documentLines;
    }
}
